<?php

    die on inclusion

?>
