<?php

    function xyzzy () { return true; }

?>
