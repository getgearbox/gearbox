<?php

    $fnord++;

?>
